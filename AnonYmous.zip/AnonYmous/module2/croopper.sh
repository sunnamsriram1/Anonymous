clear


python2 please.py

echo ""

echo "+==========================================+" | lolcat

echo ""

echo " Author : MR.JOHɴ001" | lolcat

echo "Feat Mr.
██████╗░░█████╗░██████╗░░█████╗░████████╗
██╔══██╗██╔══██╗██╔══██╗██╔══██╗╚══██╔══╝
██████╔╝██║░░██║██████╦╝██║░░██║░░░██║░░░
██╔══██╗██║░░██║██╔══██╗██║░░██║░░░██║░░░
██║░░██║╚█████╔╝██████╦╝╚█████╔╝░░░██║░░░
╚═╝░░╚═╝░╚════╝░╚═════╝░░╚════╝░░░░╚═╝░░░" | lolcat

echo "Version : 2.0"


echo "Conet Me : +918688655324"

echo "+===========================================+" | lolcat

echo ""

echo         "»———
░█▀▀█ ░█▀▀▀ ░█▀▀▀█ ▀▀█▀▀ ── ▀▀█▀▀ █▀▀█ █▀▀█ █── 
░█▀▀▄ ░█▀▀▀ ─▀▀▀▄▄ ─░█── ▀▀ ─░█── █──█ █──█ █── S
░█▄▄█ ░█▄▄▄ ░█▄▄▄█ ─░█── ── ─░█── ▀▀▀▀ ▀▀▀▀ ▀▀▀———>" | lolcat

echo ""

echo "+___________________________________________+" | lolcat



echo " 1 LITEDDOS"

echo " 2 BAJINGANv6"

echo " 3 LITETOOLS"

echo " 4 LITESCRIPT"

echo " 5 Lazymux"

echo " 6 GcoSpam"

echo " 7 SpazSms"

echo " 8 Metasploit"

echo " 9 Hash-Buster"

echo " 10 Sqlmap"

echo " 11 Bot Comment Fb"

echo " 12 Torshammer"

echo " 13 IPGeolocation"

echo " 14 Recondog"

echo " 15 Crewbot"

echo " 16 miesDeface"

echo " 17 Red_Hawk"

echo " 18 Weeman"

echo " 19 D-TECT"

echo " 20 Hammer"

echo " 21 Katoolin"

echo " 22 Termux-Api"

echo " 23 Figlet"

echo " 24 Xerxes"

echo " 25 Main Moon-Buggy"

echo " 26 Info Handphone"

echo " 27 mviSQL"

echo " 28 IESinstaller"

echo " 29 SocialFish (Phising)"

echo " 30 BinGoo (Dorking)"

echo " 31 Cupp (Wordlist)"

echo " 32 A-Rat"

echo " 33 Phising Mania (Phising)"

echo " 34 Spider Bot"

echo " 35 Tx-Tools"

echo " 36 theZoo A Live Malware "

echo " 37 TOOLSINSTALLERv4"

echo " 38 Ngrok "

echo " 39 Kali-Nethunter"

echo " 40 ezsploit"

echo " 41 hash-generator"

echo " 42 Admin-Login"

echo " 43 OSIF"

echo " 44 Termux-metasploit "

echo " 45 Root@Kali"

echo " 46 IP-Locator"

echo " 47 WH-BotNet"

echo " 48 Seeker-Tool"

echo " 49 lscript"

echo " 50 Duck_Droid" 

echo " 51 Ghost-Droid"

echo " 52 M-wiz"

echo " 53 Zphisher"

echo " 54 Termux-Style" 

echo " 55 DDoS-Exploit"

echo " 56 Tool-X"

echo " 57 Amer"

echo " 58 Shodan"

echo " 59 Termux-Login"

echo " 60 SecLists"

echo " 61 DarkFly-Tool" 

echo " 62 Instragram-Autoig"

echo " 63 Ubantu Code-Server"

echo " 64 All At 370+ Tools One Click Download"

echo " 65 Termux-All-Packages Download"


cowsay -e -f HIIII  EXIT 99 | lolcat

echo " ╭──>JOHN001"

read -p  " ╰─$ MR.AnonYmous——› " si1 

if [ $si1 = 1 ]

then

clear

toilet -f slant -F gay "LITEDDOS" | lolcat

echo "HEY---HEY:)"

echo "WELCOME"

sleep 1

apt update && apt upgrade

pkg install git

pkg install python2

git clone https://github.com/4L13199/LITEDDOS


ls
bash croopper.sh

clear

fi

if [ $si1 = 2 ]

then 

clear

toilet -f slant -F gay "BAJINGANv6" | lolcat

echo ""

sleep 1

apt update && apt upgrade

apt install git

apt install toilet

pkg install pip

pip2 install termcolor

pip2 install lolcat

git clone https://github.com/DarknessCyberTeam/BAJINGANv6

echo ""

echo "Ussername : BAJINGAN"

echo "Password : Gans"

echo ""

cd BAJINGANv6

sh BAJINGAN.sh

ls 
bash croopper.sh

fi

if [ $si1 = 3 ]

then

clear

toilet -f slant -F gay "LITETOOLS" | lolcat


echo ""

sleep 1

pkg update && pkg upgrade

pkg install git

git clone https://github.com/4L13199/LITETOOLS

cd LITETOOLS

sh LITETOOLS.sh

ls
bash croopper.sh

fi


if [ $si1 = 4 ]

then

clear

toilet -f slant -F gay "LITESCRIPT" | lolcat


echo ""

sleep 1

pkg install python2 git

git clone https://github.com/4L13199/LITESCRIPT

echo ""

echo " Buat Simpen Ke Internal"

echo " mv namascript.html /sdcard/"

echo ""

cd LITESCRIPT

python2 LITESCRIPT.py

ls
bash croopper.sh

fi


if [ $si1 = 5 ]

then

clear

toilet -f slant -F gay "Lazymux" | lolcat


echo ""

sleep 1

pkg update && pkg upgrade 

pkg install python2 pkg install git 

git clone https://github.com/Gameye98/Lazymux 

cd Lazymux

python2 lazymux.py

ls
bash croopper.sh

fi


if [ $si1 = 6 ]

then

clear

toilet -f mono12 -F metal "Gcospam" 


echo ""

sleep 1

apt upgrade && apt update

apt install git

git clone https://github.com/Amriez/gcospam

ls
bash croopper.sh

fi

if [ $si1 = 7 ]

then

clear

toilet -f slant -F gay "SpazSMS" | lolcat


echo ""

sleep 1

pkg update && pkg upgrade

pkg install git

pkg install python2

git clone https://github.com/Gameye98/SpazSMS

cd SpazSMS

ls
bash croopper.sh

fi


if [ $si1 = 8 ]

then

clear

toilet -f mono12 -F metal "Metsploite" | lolcat


echo ""

sleep 1

echo "Metasploit Installan 30-40 MenitS mohon "

apt update && apt upgrade

apt install curl

curl -LO https://raw.githubusercontent.com/Hax4us/Metasploit_termux/master/metasploit.sh

chmod +x metasploit.sh

./metasploit.sh

ls
bash croopper.sh

fi


if [ $si1 = 9 ]

then 

clear

toilet -f slant -F gay "Hash-Buster" | lolcat


echo ""

sleep 1

apt update

apt upgrade

apt install python2

apt install git

git clone https://github.com/UltimateHackers/Hash-Buster

cd Hash-Buster

python2 hash.py

cat makefile

ls
bash croopper.sh

fi

if [ $si1 = 10 ]

then

clear

toilet -f mono12 -F metal "Sqlmap" | lolcat


echo ""

sleep 1

apt update && apt upgradeapt install python

apt install python2

apt install git

git clone https://github.com/sqlmapproject/sqlmap

figlet -f standard "Install Done!" | lolcat

ls
bash croopper.sh

echo ""


fi


if [ $si1 = 11 ]

then

clear

toilet -f slant -F gay "Botkomena" | lolcat


echo ""

sleep 1

pkg update && pkg upgrade 

pkg install git 

pkg install python2 

pip2 install mechanize 

git clone https://github.com/Senitopeng/Botkomena.git 

figlet -f standard "BOTKOMENA" | lolcat

ls
bash croopper.sh

echo ""

fi

if [ $si1 = 12 ]

then

clear

toilet -f slant -F gay "Torshammer" | lolcat

echo ""

sleep 1

pkg update

pkg install git

Pkg install tor

pkg install python2

git clone https://github.com/dotfighter/torshammer.git

figlet -f standard "TORRSHAMMER" | lolcat

ls
bash croopper.sh

fi


if [ $si1 = 13 ]

then

clear

toilet -f slant -F gay "IPGeoLocation" | lolcat

sleep 1

Apt install python git 

git clone https://github.com/maldevel/IPGeoLocation.git

figlet -f standard "Installed" | lolcat

ls
bash croopper.sh

fi


if [ $si1 = 14 ]

then

clear

toilet -f slant -F gay "ReconDog" | lolcat


echo ""

sleep 1

apt update

apt install python python2 

apt install git 

git clone https://github.com/UltimateHackers/ReconDog 

ls
bash croopper.sh

fi


if [ $si1 = 15 ]

then

clear

toilet -f slant -F gay "XEit666h05t" | lolcat


echo ""

sleep 1

apt update

apt upgrade

pkg install 

git clone https://github.com/Xeit666h05t/CrewBot

figlet -f standard "INstalled" | lolcat

ls
bash croopper.sh

echo ""


fi


if [ $si1 = 16 ]

then

clear

toilet -f slant -F gay "IesDEFACE" | lolcat


echo ""

sleep 1

pkg update && pkg upgrade

pkg install bash

pkg install pip

pip2 install bash

git clone https://github.com/ALX-04/iesDEFACE

cd iesDEFACE

bash iesDeface.sh

ls
bash croopper.sh

fi

if [ $si1 = 17 ]

then

clear

toilet -f slant -F gay "RED_HAWK" | lolcat

echo ""

sleep 1

apt update 

apt install git

apt install php

git clone https://github.com/Tuhinshubhra/RED_HAWK

cd RED_HAWK 

chmod +x rhawk.php 

php rhawk.php

ls
bash croopper.sh

fi


if [ $si1 = 18 ]

then

clear

toilet -f slant -F gay "Weeman" | lolcat


echo ""

sleep 1

apt update && apt upgrade -y

apt install git -y

apt install python2 -y

git clone https://github.com/evait-security/weeman

cd weeman 

chmod 777 weeman.py 

python2 weeman.py

ls
bash croopper.sh

fi


if [ $si1 = 19 ]

then

clear

toilet -f slant -F gay "D-TECT" | lolcat


echo ""

sleep 1

apt update 

apt install git 

apt install python2

git clone https://github.com/shawarkhanethicalhacker/D-TECT 

cd D-TECT

chmod +x d-tect.py

python2 d-tect.py

ls
bash croopper.sh

fi


if [ $si1 = 20 ]

then

clear

toilet -f slant -F gay "Hammer" | lolcat


echo ""

sleep 1

pkg update

pkg upgrade

pkg install python 

pkg install git 

git clone https://github.com/cyweb/hammer

ls
bash croopper.sh

echo ""

fi


if [ $si1 = 21 ]

then

clear

toilet -f slant -F gay "Katoolin" | lolcat


echo ""

sleep 1

Pkg install git

Pkg install python2

Pkg install gnupg

Pkg install nano

git clone https://github.com/LionSec/katoolin.git

cd katoolin

chmod +x katoolin.py

python2 katoolin.py

ls
bash croopper.sh

fi


if [ $si1 = 22 ]

then

clear

toilet -f slant -F gay "Termux-Api" | lolcat


echo ""

sleep 1

pkg install termux-api

termux-telephony-call +916281965266

ls
bash croopper.sh

fi


if [ $si1 = 23 ]

then

clear

toilet -f slant -F gay "Figlet" | lolcat


echo ""

sleep 1

pkg install figlet

toilet -f mono12 -F metal "Any Text"

ls
bash croopper.sh

fi


if [ $si1 = 24 ]

then

clear

toilet -f slant -F gay "Xerxes" | lolcat

echo ""

sleep 1

apt install git

apt install clang

git clone https://github.com/zanyarjamal/xerxes

echo ""

ls
bash croopper.sh

fi


if [ $si1 = 25 ]

then

clear

toilet -f slant -F gay "Moon-Buggy" | lolcat


echo ""

sleep 1

pkg install moon-buggy

moon-buggy

ls
bash croopper.sh

fi


if [ $si1 = 26 ]

then

clear

toilet -f slant -F gay "Neofetch" | lolcat


echo ""

sleep 1

pkg install neofetch

neofetch

ls
bash croopper.sh

fi

if [ $si1 = 27 ]

then

clear

toilet -f slant -F gay "viSQL" | lolcat


echo ""

sleep 1

apt update

apt install python2

apt install git

git clone https://github.com/blackvkng/viSQL

ls
bash croopper.sh

fi

if [ $si1 = 28 ]

then

clear

toilet -f slant -F gay "iesInstall" | lolcat

echo ""

sleep 1

pkg update && pkg upgrade

pkg install pip

git clone https://github.com/ALX-04/iesInstall

cd iesInstall

bash ./IESinstaller

ls
bash croopper.sh

fi

if [ $si1 = 29 ]

then

clear

toilet -f slant -F gay "SocialFish" | lolcat


echo ""

sleep 1

pkg install php

pkg install python2

pkg install git

pkg install curl

git clone https://github.com/Lexiie/SocialFish.git

mv SocialFish $HOME

cd $HOME/SocialFish

pip2 install wget

chmod +x SocialFish.py

python2 SocialFish.py

ls
bash croopper.sh

fi

if [ $si1 = 30 ]

then

clear

toilet -f slant -F gay "Bingoo" | lolcat

echo ""

sleep 1

apt update && upgrade -y

apt-get install lynx

apt install grep

apt-get install curl

apt install git

git clone https://github.com/Hood3dRob1n/BinGoo.git

cd BinGoo

termux-fix-shebang bingoo

chmod +x bingoo

bash bingoo

ls
bash croopper.sh

fi

if [ $si1 = 31 ]

then

clear

toilet -f slant -F gay "Cupp" | lolcat
echo ""

sleep 1

pkg update && pkg upgrade

pkg install python2

pkg install git

git clone https://github.com/Mebus/cupp.git

cd cupp

echo " mv wordlist.txt /sdcard/"

echo ""

python2 cupp.py -i

ls
bash croopper.sh

fi

if [ $si1 = 32 ]

then

clear

toilet -f slant -F gay "A-Rat" | lolcat

echo ""

sleep 1

pkg update && pkg upgrade

pkg install python2

pkg install git

git clone https://github.com/Xi4u7/A-Rat.git

cd A-Rat

echo " Cara Membuat Payload"

echo " http://senitopeng.blogspot.com/2017/12/a-rat-membuat-backdoortrojan-buka.html?m=1"

echo ""

echo "10 Detik Lagi A-Rat"

echo " Akan Di Mulai"

echo " "

sleep 10

python2 A-Rat.py

ls
bash croopper.sh

fi

if [ $si1 = 33 ]

then

clear

toilet -f slant -F gay "Mancing" | lolcat

echo ""

sleep 1

apt update && apt upgrade

apt install python2

apt install apache2

apt install php

apt install git

git clone https://github.com/Senitopeng/Mancing.git

cd Mancing

sleep 10

python2 mancing.py

ls
bash croopper.sh

fi

if [ $si1 = 34 ]

then

clear

toilet -f slant -F gay "SpiderBot" | lolcat


echo ""

sleep 1

apt update && apt upgrade

apt install php

apt install git

git clone https://github.com/Cvar1984/SpiderBot.git

cd SpiderBot

echo ""

echo " php botkoment.php"

echo ""

ls
bash croopper.sh

fi

if [ $si1 = 35 ]

then

clear

toilet -f slant -F gay "TX-tool" | lolcat

echo ""

sleep 1

pkg update && pkg upgrade

pkg install python2

pkg install git

git clone https://github.com/kuburan/txtool.git

echo ""

echo " cd txtool"

echo " ./install.py atau python2 install.py"

echo " txtool"

echo ""

ls
bash croopper.sh

fi

if [ $si1 = 36 ]

then

clear

toilet -f big -F gay "theZoo" | lolcat
echo "
█░█░█ ▄▀█ █▀█ █▄░█ █ █▄░█ █▀▀
▀▄▀▄▀ █▀█ █▀▄ █░▀█ █ █░▀█ █▄█" | lolcat
echo "🅆🄰🅁🄽🄸🄽🄶" | lolcat
echo "ɪ'ᴍ Nᴏᴛ ʀᴇsᴘᴏɴsɪʙɪʟɪᴛɪᴇs ᴛʜɪs ᴛᴏᴏʟ" | lolcat

sleep 1

git clone https://github.com/ytisf/theZoo.git

cd theZoo

pip install --user -r requirements.txt

python theZoo.py

clear

ls
bash croopper.sh

fi

if [ $si1 = 37 ]

then

clear

toilet -f slant -F gay "TOOLSINSTALLERv4" | lolcat

sleep 1

git clone https://github.com/TUANB4DUT/TOOLSINSTALLERv4.git

ls
bash croopper.sh

fi

if [ $si1 = 99 ]

then

clear

echo " 
▒█▀▀█ █░░█ █▀▀ 　 ▒█▀▀█ █░░█ █▀▀ 
▒█▀▀▄ █▄▄█ █▀▀ 　 ▒█▀▀▄ █▄▄█ █▀▀ 
▒█▄▄█ ▄▄▄█ ▀▀▀ 　 ▒█▄▄█ ▄▄▄█ ▀▀▀ 

▒█▀▀▄ █░░█ █▀▀▄ █▀▀ 
▒█░▒█ █░░█ █░░█ █▀▀ 
▒█▄▄▀ ░▀▀▀ ▀▀▀░ ▀▀▀  Dud Sunnam sriram "  | lolcat

date | lolcat

cowsay -e -f LOOK UP Dud | lolcat

exit

fi

if [ $si1 = 0 ]

then

clear

ls

bash croopper.sh

fi


if [ $si1 = 38 ]

then

clear

toilet -f big -F gay " Ngrok "
sleep 1
apt update && apt upgrade
apt install wget
mkdir ngrok
cd ~/ngrok
wget https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-arm.zip
mv ngrok-stable-linux-arm.zip $HOME
$HOME/unzip ngrok-stable-linux-arm.zip
cd ~/

ls
bash croopper.sh

fi

if [ $si1 = 39 ]

then

clear

toilet -f big -F gay "KaliNethunter"
sleep 1
apt update
apt upgrade
apt install git
git clone https://github.com/Hax4us/Nethunter-In-Termux.git
mv Nethunter-In-Termux $HOME
cd $HOME/Nethunter-In-Termux
chmod 777 kalinethunter
sh kalinethunter

fi

if [ $si1 = 40 ]

then

clear

toilet -f mono12 -F metal "ezsploit"
sleep 1
apt update
apt upgrade
apt install git
git clone https://github.com/rand0m1ze/ezsploit
mv ezsploit $HOME
cd $HOME/ezsploit
bash ezsploit.sh

fi

if [ $si1 = 41 ]

then

clear

toilet -f big -F gay "hash-generator"

sleep 1

apt update
apt upgrade
apt install git
apt install python2
git clone https://github.com/CiKu370/hash-generator
mv hash-generator $HOME
cd $HOME/hash-generator
python2 hashgen.py

fi

if [ $si1 = 42 ]

then

clear

toilte -f mono12 -F metal "Admin-Login" | lolcat

sleep 1

git clone https://github.com/DarknessCyberTeam/Scan-Website-Admin-Login
mv Scan-Website-Admin-Login $HOME
cd $HOME/Scan-Website-Admin-Login
python2 Admin-Login.py

ls
bash croopper.sh
fi

if [ $si1 = 43 ]

then

clear

toilet -f mono12 -F metal "OSIF"

sleep 1

apt update
apt upgrade
apt install git
apt install python2
git clone https://github.com/CiKu370/OSIF
mv OSIF $HOME
cd $HOME/OSIF
python2 osif.py

ls
bash croopper.sh

fi


if [ $si1 = 44 ]

then

clear

toilet -f mono12 -F metal "Termux-metasploit"
sleep 1
apt update
apt upgrade
apt install git
git clone https://github.com/verluchie/termux-metasploit
mv termux-metasploit $HOME
cd $HOME/termux-metasploit
sh install.sh

ls
bash croopper.sh

fi

if [ $si1 = 45 ]

then

clear

toilet -f mono12 -F metal "Kali@Linux"

termux-setup-storage
pkg install wget
wget -O install-nethunter-termux https://offs.ec/2MceZWr
chmod +x install-nethunter-termux
./install-nethunter-termux

toilet -f mono12 -F metal "Install Done!"

ls
bash croopper.sh

fi


if [ $si1 = 46 ]

then

clear

toilet -f big -F gay "IP-Locator"

sleep 1

apt update
apt upgrade
apt install perl
apt install git
git clone https://github.com/zanyarjamal/IP-Locator
mv IP-Locator $HOME
cd $HOME/IP-Locator
perl ip-locator.pl

ls 
bash croopper.sh

fi

if [ $si1 = 47 ]

then

clear

toilet -f mono12 -F metal "WH-BotNet"

sleep 1

apt update
apt upgrade
git clone https://github.com/wh-Cyberspace/WH-BotNet.git
echo " cd WH-BotNet/All-linux " | lolcat
echo " chmod +x all-linux.sh "  | lolcat
echo " bash all-linux.sh "      | lolcat
echo " 🔓 LOGIN INFO.."         | lolcat
echo " Username : wh-hackerexploit"  | lolcat

echo " password : wh-botnet "      | lolcat

echo "Your browser access >> [ http://《YOUR IPv4》:22533 ]" | lolcat

sleep 10

ls
bash croopper.sh

fi

if [ $si1 = 48 ]
then

clear

toilet -f mono12 -F metal "Seeker"

git clone https://github.com/thewhiteh4t/seeker.git
cd seeker/
pkg update
pkg install python php
pip3 install requests

echo "python3 seeker.py -t manual" | lolcat
echo "./ngrok http 8080" | lolcat
echo "python3 seeker.py -t manual -k <filename>" | lolcat
echo "python3 seeker.py -t manual -p 1337" | lolcat
echo "./ngrok http 1337" | lolcat

sleep 10

ls 
bash crooper.sh

fi

if [ $si1 = 49 ]
then

clear

toilet -f mono12 -F metal "Lscript"

git clone https://github.com/arismelachroinos/lscript.git

ls
bash croopper.sh

fi


if [ $si1 = 50 ]
then

clear

toilet -f mono12 -F metal "Duck_Droid"
apt update
apt upgrade -y
pkg install python -y
git clone https://github.com/T4Termux/Duck_Droid.git

ls
bash croopper.sh

fi

if [ $si1 = 51 ]
then
clear

toilet -f mono12 -F metal "Ghost-Droid"

git clone https://github.com/GhosTmaNHarsh/Ghost-Droid.git

ls
bash croopper.sh

fi

if [ $si1 = 52 ]
then
clear

toilet -f mono12 -F metal "M-wiz"

git clone https://github.com/noob-hackers/m-wiz.git

ls
bash croopper.sh

fi

if [ $si1 = 53 ]
then 
clear

toilet -f mono12 -F metal "Zphisher"

git clone https://github.com/htr-tech/zphisher.git

ls 
bash croopper.sh

fi

if [ $si1 = 54 ]
then

clear

toilet -f mono12 -F metal "Termux-Style"

git clone https://github.com/adi1090x/termux-style.git

ls
bash croopper.sh

fi

if [$si1 = 55 ]
then

clear

toilet -f mono12 -F metal "DDOS-Exploit"

git clone https://github.com/649/Memcrashed-DDoS-Exploit.git

ls
bash croopper.sh

fi

if [ $si1 = 56 ]
then
clear

toilet -f mono12 -F metal "Tool-X"

git clone https://github.com/rajkumardusad/Tool-X.git

ls
bash croopper.sh
fi

if [ $si1 = 57 ]
then
clear

toilet -f mono12 -F metal "Amer"

git clone https://github.com/Amerlaceset/Amer.git

ls
bash croopper.sh

fi

if [ $si1 = 58 ]
then
clear

toilet -f mono12 -F metal "Shodan"

git clone https://github.com/polarityio/shodan.git

ls
bash croopper.sh

fi

if [ $si1 = 59 ]
then
clear

toilet -f mono12 -F metal "Termux-Login"


git clone git clone https://github.com/htr-tech/termux-login.git

ls
bash croopper.sh

fi

if [ $si1 = 60 ]
then
clear

toilet -f mono12 -F metal "SecLists"


git clone https://github.com/danielmiessler/SecLists.git

ls
bash croopper.sh
fi

if [ $si1 = 61 ]
then
clear

toilet -f mono12 -F metal "DarkFly-tool"

git clone https://github.com/Ranginang67/DarkFly-Tool.git

ls
bash croopper.sh

fi

if [ $si1 = 62 ]
then

clear
 
toilet -f mono12 -F metal "Instargram-Autoig"

git clone https://github.com/noob-hackers/autoig

ls
bash croopper.sh

fi

if [ $si1 = 63 ]
then

clear

pkg install wget openssl-tool proot -y && hash -r && wget https://raw.githubusercontent.com/EXALAB/AnLinux-Resources/master/Scripts/Installer/Ubuntu/ubuntu.sh && bash ubuntu.sh

./start-ubuntu.sh

wget https://github.com/cdr/code-server/releases/download/2.1698/code-server2.1698-vsc1.41.1-linux-arm64.tar.gz

tar -xvf ./code-server2.1698-vsc1.41.1-linux-arm64.tar.gz

cp ./code-server2.1698-vsc1.41.1-linux-arm64/code-server /bin

echo "START-code-server"
sleep 4
echo "START- http//:localhost:8080"
sleep 3
echo "export PASSWORD=<your_password>"
sleep 5

ls
bash croopper.sh

fi

if [ $si1 = 64 ]
then
clear

cd module2

./data.sh

echo " 370+ Tools Download"

ls
bash croopper.sh

fi

if [ $si1 = 65 ]
then

cd module2

bash termux.sh

echo "Termux Full Download"

ls
bash croopper.sh

fi

